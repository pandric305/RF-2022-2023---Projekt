var dorita980 = require("rest980");

var myRobotViaLocal = new dorita980.Local(
  "80B5071411436660",
  ":1:1684416346:djE46sIJdkHappo2",
  "172.20.10.9"
); // robot IP address

myRobotViaLocal.on("connect", init);
/*myRobotViaLocal.setSong(0, [
  [72, 32],
  [76, 32],
  [79, 32],
  [72, 32],
]);*/

function init() {
  myRobotViaLocal
    .setSong(0, [
      [72, 32],
      [76, 32],
      [79, 32],
      [72, 32],
    ])
    .play(1);
}
