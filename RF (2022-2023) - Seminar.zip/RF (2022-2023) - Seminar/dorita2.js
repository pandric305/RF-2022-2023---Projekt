var dorita980 = require("dorita980");

var myRobotViaLocal = new dorita980.Local(
  "80B5071411436660",
  ":1:1684416346:djE46sIJdkHappo2",
  "172.20.10.9"
); // robot IP address

myRobotViaLocal.on("connect", init);

function init() {
  myRobotViaLocal
    .pause()
    .then(() => myRobotViaLocal.end()) // disconnect to leave free the channel for the mobile app.
    .catch(console.log);
}
